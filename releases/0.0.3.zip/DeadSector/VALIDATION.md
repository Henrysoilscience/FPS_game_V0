# Release validation — 0.0.3

Validated on October 29, 2026 in the Linux cloud workspace.

- Production TypeScript/build and standalone HTML generation: passed.
- All three zombie variants use the shared black head-and-hat material; vertex colors are disabled for the merged head mesh and its headshot hit zone is preserved. Verified against constructed character meshes.
- Embedded standalone browser checks: **2 passed, 0 failed, 0 skipped** for this build. Networking was offline and the HTML was supplied through an intercepted response without a server. Checks cover bilingual menus, mouse capture, audio, movement, weapon switching/reloading, and zombie eliminations.
- The earlier 13 simulation tests and four full browser tests passed on the previous standalone release. They were not rerun for this visual-only change.
- The artifact includes all JavaScript, CSS, icon and procedural assets in one HTML file. Players need no Python installation or local server.
- Direct file:// validation remains blocked by the cloud browser administrator policy (ERR_BLOCKED_BY_ADMINISTRATOR); no successful direct-file launch test is claimed. The actual file-protocol suite remains available via npm run test:standalone in an environment permitting local-file navigation.

Browser checks use headless Chromium with SwiftShader software rendering. These checks establish functional behavior and self-containment, not hardware-specific frame rates or listening-device audio quality. Single-player scope and existing gameplay are unchanged.
