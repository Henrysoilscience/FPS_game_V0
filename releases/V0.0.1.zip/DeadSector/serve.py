#!/usr/bin/env python3
"""Serve an extracted Dead Sector build locally. Python 3 standard library only."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
import threading
import webbrowser


def main():
    parser = argparse.ArgumentParser(description="Start Dead Sector / 启动隔离禁区")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--no-open", action="store_true", help="Do not open a browser automatically")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    site = root / "dist" if (root / "dist" / "index.html").is_file() else root
    if not (site / "index.html").is_file():
        print("No production build found. Run npm run build first.", file=sys.stderr)
        return 1
    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), partial(SimpleHTTPRequestHandler, directory=str(site)))
    except OSError as error:
        print(f"Could not start server: {error}. Try --port 8081.", file=sys.stderr)
        return 1
    url = f"http://127.0.0.1:{server.server_port}/"
    print(f"Dead Sector is running. Open in Chrome: {url}", flush=True)
    print("Press Ctrl+C to stop. / 按 Ctrl+C 停止。", flush=True)
    if not args.no_open:
        threading.Timer(.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
